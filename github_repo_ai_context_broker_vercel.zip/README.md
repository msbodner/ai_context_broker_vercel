# AI Context Broker for Vercel
Full Next.js + Edge + AI agent project.
